#!/bin/bash
echo "패치 관리,AP-07,안정화 버전 및 패치 적용,상,N/A" >> apache_report.csv